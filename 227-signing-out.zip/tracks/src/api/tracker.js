import axios from "axios";

export default axios.create({
  baseURL: "http://af95209e13bf.ngrok.io",
});
